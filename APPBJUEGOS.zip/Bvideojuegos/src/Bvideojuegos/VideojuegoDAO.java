package Bvideojuegos;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VideojuegoDAO {

    public List<Videojuego> obtenerTodos() throws SQLException {
        List<Videojuego> videojuegos = new ArrayList<>();
        String sql = "SELECT * FROM Videojuegos";
        
        try (Connection con = DatabaseConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Videojuego v = new Videojuego(rs.getInt("ID"), rs.getString("Titulo"), rs.getString("Genero"),
                        rs.getString("Clasificacion"), rs.getString("Plataforma"));
                videojuegos.add(v);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return videojuegos;
    }

    public void insertar(Videojuego videojuego) throws SQLException {
        String sql = "INSERT INTO Videojuegos (Titulo, Genero, Clasificacion, Plataforma) VALUES (?, ?, ?, ?)";
        
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pstmt = con.prepareStatement(sql)) {
            
            pstmt.setString(1, videojuego.getTitulo());
            pstmt.setString(2, videojuego.getGenero());
            pstmt.setString(3, videojuego.getClasificacion());
            pstmt.setString(4, videojuego.getPlataforma());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void actualizar(Videojuego videojuego) throws SQLException {
        String sql = "UPDATE Videojuegos SET Titulo = ?, Genero = ?, Clasificacion = ?, Plataforma = ? WHERE ID = ?";
        
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pstmt = con.prepareStatement(sql)) {
            
            pstmt.setString(1, videojuego.getTitulo());
            pstmt.setString(2, videojuego.getGenero());
            pstmt.setString(3, videojuego.getClasificacion());
            pstmt.setString(4, videojuego.getPlataforma());
            pstmt.setInt(5, videojuego.getId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void borrar(int id) throws SQLException {
        String sql = "DELETE FROM Videojuegos WHERE ID = ?";
        
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement pstmt = con.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
