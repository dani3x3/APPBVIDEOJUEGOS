package Bvideojuegos;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

public class VideojuegosApp extends JFrame {
    private JTextField txtId, txtTitulo, txtGenero, txtClasificacion, txtPlataforma;
    private JTable table;
    private DefaultTableModel tableModel;
    private VideojuegoDAO dao;

    public VideojuegosApp() {
        dao = new VideojuegoDAO();
        
        setTitle("Videojuegos App");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel de entrada de datos
        JPanel panelEntrada = new JPanel(new GridLayout(5, 2));
        panelEntrada.add(new JLabel("ID:"));
        txtId = new JTextField();
        panelEntrada.add(txtId);
        panelEntrada.add(new JLabel("Titulo:"));
        txtTitulo = new JTextField();
        panelEntrada.add(txtTitulo);
        panelEntrada.add(new JLabel("Genero:"));
        txtGenero = new JTextField();
        panelEntrada.add(txtGenero);
        panelEntrada.add(new JLabel("Clasificacion:"));
        txtClasificacion = new JTextField();
        panelEntrada.add(txtClasificacion);
        panelEntrada.add(new JLabel("Plataforma:"));
        txtPlataforma = new JTextField();
        panelEntrada.add(txtPlataforma);

        // Botones de acciones
        JPanel panelBotones = new JPanel(new GridLayout(1, 4));
        JButton btnConsultar = new JButton("Consultar");
        btnConsultar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    cargarDatos();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        panelBotones.add(btnConsultar);

        JButton btnInsertar = new JButton("Insertar");
        btnInsertar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    insertar();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        panelBotones.add(btnInsertar);

        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    actualizar();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        panelBotones.add(btnActualizar);

        JButton btnBorrar = new JButton("Borrar");
        btnBorrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    borrar();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        panelBotones.add(btnBorrar);

        // Tabla de datos
        tableModel = new DefaultTableModel();
        tableModel.setColumnIdentifiers(new String[]{"ID", "Titulo", "Genero", "Clasificacion", "Plataforma"});
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        add(panelEntrada, BorderLayout.NORTH);
        add(panelBotones, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);
    }

    private void cargarDatos() throws SQLException {
        List<Videojuego> videojuegos = dao.obtenerTodos();
        tableModel.setRowCount(0);
        for (Videojuego v : videojuegos) {
            tableModel.addRow(new Object[]{v.getId(), v.getTitulo(), v.getGenero(), v.getClasificacion(), v.getPlataforma()});
        }
    }

    private void insertar() throws SQLException {
        String titulo = txtTitulo.getText();
        String genero = txtGenero.getText();
        String clasificacion = txtClasificacion.getText();
        String plataforma = txtPlataforma.getText();

        Videojuego videojuego = new Videojuego(0, titulo, genero, clasificacion, plataforma);
        dao.insertar(videojuego);
        cargarDatos();
    }

    private void actualizar() throws SQLException {
        int id = Integer.parseInt(txtId.getText());
        String titulo = txtTitulo.getText();
        String genero = txtGenero.getText();
        String clasificacion = txtClasificacion.getText();
        String plataforma = txtPlataforma.getText();

        Videojuego videojuego = new Videojuego(id, titulo, genero, clasificacion, plataforma);
        dao.actualizar(videojuego);
        cargarDatos();
    }

    private void borrar() throws SQLException {
        int id = Integer.parseInt(txtId.getText());
        dao.borrar(id);
        cargarDatos();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new VideojuegosApp().setVisible(true);
            }
        });
    }
}
